//
// Created by nikola354 on 31.05.22.
//

#ifndef SVG_FILES_HELPERS_H
#define SVG_FILES_HELPERS_H

bool isBetween(double number, double first, double second);

double min(double f, double s);

double max(double f, double s);

#endif //SVG_FILES_HELPERS_H
