//
// Created by nikola354 on 01.06.22.
//

#ifndef BANK_SYSTEM_ERRORS_H
#define BANK_SYSTEM_ERRORS_H

#include "String.h"

const String &positiveNumberError(const String &field);

const String& positiveDoubleError(const String &field);

#endif //BANK_SYSTEM_ERRORS_H
