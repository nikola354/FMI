//
// Created by nikola354 on 01.06.22.
//

#ifndef BANK_SYSTEM_HELPERS_H
#define BANK_SYSTEM_HELPERS_H

#include "String.h"

int countDigits(int number);

char toChar(int digit);

String toStr(int number);

#endif //BANK_SYSTEM_HELPERS_H
