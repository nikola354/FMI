#include <iostream>
#include "../headers/Vector.h"

#include "../headers/Dialog.h"

int main() {
    Dialog dialog;
    dialog.welcomeDialog();

    return 0;
}
