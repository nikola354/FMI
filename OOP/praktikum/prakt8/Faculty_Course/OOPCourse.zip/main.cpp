#include <iostream>

//classes cannot extend other classes

#include "OOPCourse.h"
#include <string>

using std::cout;
using std::endl;

int main() {
    try{
        OOPCourse p("Lecturer1", "Assistant1", "Assistant2");

        p.addStudent("Stoycho Kyosev", 42069);
        p.addStudent("Yavor Alexandrov", 69420);
        p.addStudent("Angel Dimitriev", 00666);

        p.addGrade(42069, "HW1", 4.0, "Assistant1");
        p.addGrade(00666, "HW1", 5.5, "Lecturer1");
        p.addGrade(42069, "K1", 5.5, "Assistant1");

        cout << p.getAverageForCourse() << endl;

        p.removeStudent(42069);

        cout << p.getAverageGradePerTask("HW1") << endl;

        p.changeGrade(00666, 6, "HW1");

        cout << p.getAverageGradePerTask("HW1") << endl;

        cout << p.getAverageFromTeacher("Lecturer1") << endl;
    } catch (const char *error) {
        cout << error << endl;
    }


    return 0;
}
